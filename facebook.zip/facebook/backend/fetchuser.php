<?php

require_once 'connect.php';

session_start();


global $connection;
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM `users` WHERE password = '$password' AND email = '$email'";
echo $email;
$result = mysqli_query($connection, $sql);

if (mysqli_num_rows($result) > 0) { // function
    echo "Succesfully!";
    header("location: ../home.php");
    $row = mysqli_fetch_assoc($result);
    $_SESSION['user'] = [
        "id" => $row['id'],
        "password" => $row['password'],
        "email" => $row['email']
    ];
} else {
    echo "Unsuccesfully!";
}


