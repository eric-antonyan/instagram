<pre>
<?php 

require_once 'connect.php';

if (isset($_POST["isSubmit"])) {
    global $connection;
    $emailorphone = $_POST['emailornumber'];
    $password = $_POST['pswd'];

    $sql = "INSERT INTO `users` (`email`, `password`) VALUES ('$emailorphone', '$password')";
    $retult = mysqli_query($connection, $sql);
}

?>