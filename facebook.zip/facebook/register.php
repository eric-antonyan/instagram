<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    require_once 'components/head.php';
    ?>
</head>

<body>
    <img width="300px" src="https://static.xx.fbcdn.net/rsrc.php/y1/r/4lCu2zih0ca.svg" alt="">
    <p>Facebook помогает вам всегда оставаться на связи и общаться со своими знакомыми.</p>
    <form action="backend/adduser.php" method="post">
        <input placeholder="Электронный адрес или номер телефона" required name="emailornumber" type="email">
        <br>
        <input placeholder="Пароль" name="pswd" type="password">
        <br>
        <button type="submit" name="isSubmit" class="pointer">Создать новый аккаунт</button>
        <br>
        <a href="login.php">Login</a>
    </form>
</body>

</html>