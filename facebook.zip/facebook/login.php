<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    require_once 'components/head.php';
    ?>
</head>

<body>
    <img width="300px" src="https://static.xx.fbcdn.net/rsrc.php/y1/r/4lCu2zih0ca.svg" alt="">
    <p>Facebook помогает вам всегда оставаться на связи и общаться со своими знакомыми.</p>
    <form action="backend/fetchuser.php" method="post">
        <input placeholder="Электронный адрес или номер телефона" required name="email" type="email">
        <br>
        <input placeholder="Пароль" name="password" type="password">
        <br>
        <button type="submit" name="isSubmit" class="pointer">Авторизуйтесь</button>
        <br>
        <a href="register.php">Register</a>
    </form>
</body>

</html>