<?php

require "db.php";
require "functions.php";

session_start();

$username = $_POST['username'];
$password = $_POST['password'];

$_sql = "SELECT * FROM `admin` WHERE username='$username' AND password='$password'";

$_res = q($_sql);

if (mysqli_num_rows($_res) > 0) {
    header("location: .././?apanel");
    $_SESSION['esuccess'] = true;
    echo "ok";
} else {
    header("location: ?page=apanel");
}