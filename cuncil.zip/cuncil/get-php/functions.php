<?php

require "db.php";

function q($sql_syntax) {
    global $db;
    return mysqli_query($db, $sql_syntax);
}