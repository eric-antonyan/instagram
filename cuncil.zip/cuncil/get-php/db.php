<?php

$host = "localhost";
$user = "root";
$password = "";
$dbname = "cuncil";

$db = mysqli_connect($host, $user, $password, $dbname);